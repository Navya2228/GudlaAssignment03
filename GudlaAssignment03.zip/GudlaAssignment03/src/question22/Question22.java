package question22;

public class Question22 {
	public static void main(String[] args) {
		String s = "hello";
		s = s + " world";
		System.out.println(s);
	}
}
