package question7;

public class Question7 {
	class Question7 {
	    final Question7() {  
	    }
	}
}
