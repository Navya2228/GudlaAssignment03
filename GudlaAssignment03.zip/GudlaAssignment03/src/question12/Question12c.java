package question12;

public class Question12c {
	 @Override
	    protected void finalize() throws Throwable {
	       
	        super.finalize();
	    }
}
