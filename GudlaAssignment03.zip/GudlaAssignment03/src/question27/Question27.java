package question27;

public class Question27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
